PAINEL M10 — projeto Android inicial
Créditos: m10miguelnz123

O QUE JÁ ESTÁ NO PROJETO
- Interface Android com tema preto/roxo neon.
- Controle de velocidade de 50 a 1000 ms.
- Presets Rápido (50 ms), Normal (150 ms) e Lento (350 ms).
- Salvamento local da velocidade escolhida.
- Verificação e solicitação de autorização do Shizuku.

IMPORTANTE — ESTADO DO PROJETO
Este ZIP contém o CÓDIGO-FONTE de um protótipo Android, não um APK instalado.
Não foi possível compilar ou testar neste ambiente porque Android SDK/Gradle não estão disponíveis.
O botão de QBUG permanece bloqueado de propósito: ainda é necessário definir e testar como o comando
"ATIRAR" será enviado no MTA Mobile (tecla de teclado ou clique do mouse). O uso de input tap não
equivale a um clique físico do mouse e não deve ser presumido como compatível com o jogo.
A sequência LITEFOOT também ainda não foi fornecida.

COMO ABRIR
1. Extraia o ZIP.
2. Abra a pasta "PAINEL_M10_Android" no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Compile/execute em um aparelho Android para testar a interface.
5. Instale e inicie o Shizuku separadamente e conceda a autorização quando solicitada.

Compatibilidade de execução das macros depende da versão do Android, Shizuku, MTA Mobile
e do método de entrada usado pelo jogo. Este protótipo ainda não injeta comandos de jogo.


COMPILAR SEM PC (GitHub Actions)
1. No navegador do celular, entre em https://github.com e crie um repositório novo chamado PAINEL-M10.
2. Extraia este ZIP no celular.
3. No repositório, use Add file > Upload files e envie TODOS os arquivos e pastas que estão dentro de PAINEL_M10_Android, incluindo a pasta oculta .github.
   Se o navegador não mostrar .github, use o modo "site para computador" ou envie a pasta/arquivo do workflow separadamente criando .github/workflows/android-apk.yml.
4. Faça Commit changes na branch main.
5. Abra a aba Actions do repositório e aguarde o workflow "Build PAINEL M10 APK" terminar.
6. Abra a execução concluída, vá até Artifacts e baixe PAINEL-M10-debug-apk.zip.
7. Extraia esse ZIP e instale app-debug.apk no celular.

O APK gerado pelo GitHub Actions é uma versão debug de teste, não uma versão publicada.
O workflow compila o protótipo; isso NÃO significa que QBUG/LITEFOOT estejam implementados ou validados no jogo.
