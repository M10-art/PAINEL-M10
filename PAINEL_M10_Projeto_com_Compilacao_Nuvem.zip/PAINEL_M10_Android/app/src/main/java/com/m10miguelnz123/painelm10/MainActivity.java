package com.m10miguelnz123.painelm10;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 1001;
    private TextView shizukuStatus, speedValue, presetStatus, macroStatus;
    private SeekBar speedBar;
    private SharedPreferences prefs;
    private int speed = 150;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
        (requestCode, grantResult) -> updateShizukuStatus();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9,11,18));
        getWindow().setNavigationBarColor(Color.rgb(9,11,18));
        prefs = getSharedPreferences("m10_settings", MODE_PRIVATE);
        speed = prefs.getInt("speed_ms", 150);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        buildUi();
        updateShizukuStatus();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawableBox bg(int color, int stroke) {
        return new GradientDrawableBox(color, stroke, dp(18));
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(22), dp(18), dp(24));
        page.setBackgroundColor(Color.rgb(9,11,18));
        scroll.addView(page);

        TextView title = text("PAINEL M10", 26, Color.rgb(216,180,254), true);
        title.setGravity(Gravity.CENTER);
        page.addView(title);
        TextView sub = text("MTA MOBILE  •  MACROS", 11, Color.rgb(167,139,250), true);
        sub.setGravity(Gravity.CENTER);
        page.addView(sub);
        addGap(page, 20);

        LinearLayout shizukuCard = card(page, "CONEXÃO SHIZUKU");
        shizukuStatus = text("Verificando Shizuku...", 14, Color.WHITE, false);
        shizukuCard.addView(shizukuStatus);
        Button permission = button("CONECTAR / AUTORIZAR SHIZUKU");
        permission.setOnClickListener(v -> {
            if (Shizuku.isPreV11()) {
                status("Atualize o Shizuku para uma versão compatível.");
            } else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                updateShizukuStatus();
            } else {
                Shizuku.requestPermission(REQUEST_CODE);
            }
        });
        shizukuCard.addView(permission);

        addGap(page, 14);
        LinearLayout qbug = card(page, "MACRO PRINCIPAL");
        qbug.addView(text("QBUG", 25, Color.rgb(192,132,252), true));
        qbug.addView(text("Execução por toque único • sem repetição automática", 12, 0xFFB8AEC5, false));
        macroStatus = text("Aguardando configuração do comando ATIRAR", 12, 0xFFFFD18A, false);
        qbug.addView(macroStatus);
        Button run = button("TESTAR QBUG");
        run.setOnClickListener(v -> status("O QBUG ainda não foi habilitado: falta definir como o comando ATIRAR será enviado (tecla ou clique do mouse)."));
        qbug.addView(run);

        addGap(page, 14);
        LinearLayout settings = card(page, "VELOCIDADE DO QBUG");
        speedValue = text("", 22, Color.rgb(216,180,254), true);
        settings.addView(speedValue);
        speedBar = new SeekBar(this);
        speedBar.setMax(950);
        speedBar.setProgress(speed - 50);
        speedBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(192,132,252)));
        speedBar.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.rgb(216,180,254)));
        settings.addView(speedBar);
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.HORIZONTAL);
        TextView fast = text("50 ms • Rápido", 10, 0xFFAAA3B8, false);
        TextView slow = text("1000 ms • Lento", 10, 0xFFAAA3B8, false);
        labels.addView(fast, new LinearLayout.LayoutParams(0, -2, 1));
        slow.setGravity(Gravity.RIGHT);
        labels.addView(slow, new LinearLayout.LayoutParams(0, -2, 1));
        settings.addView(labels);
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                speed = p + 50;
                updateSpeedLabel();
                if (user) prefs.edit().putInt("speed_ms", speed).apply();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        updateSpeedLabel();

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presets.setGravity(Gravity.CENTER);
        presets.addView(presetButton("RÁPIDO", 50), weighted());
        presets.addView(presetButton("NORMAL", 150), weighted());
        presets.addView(presetButton("LENTO", 350), weighted());
        settings.addView(presets);

        addGap(page, 14);
        LinearLayout lite = card(page, "MACRO SECUNDÁRIA");
        lite.addView(text("LITEFOOT", 22, Color.rgb(167,139,250), true));
        lite.addView(text("Aguardando definição da sequência.", 12, 0xFFAAA3B8, false));

        addGap(page, 18);
        TextView credits = text("CRÉDITOS  •  m10miguelnz123", 12, Color.rgb(167,139,250), true);
        credits.setGravity(Gravity.CENTER);
        page.addView(credits);
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1);
        p.setMargins(dp(3), dp(8), dp(3), 0);
        return p;
    }

    private Button presetButton(String label, int value) {
        Button b = button(label);
        b.setOnClickListener(v -> {
            speed = value;
            speedBar.setProgress(value - 50);
            prefs.edit().putInt("speed_ms", speed).apply();
            updateSpeedLabel();
        });
        return b;
    }

    private void updateSpeedLabel() {
        if (speedValue != null) speedValue.setText(String.format(Locale.US, "Intervalo: %d ms", speed));
    }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(14), dp(15), dp(14));
        box.setBackground(bg(Color.rgb(23,20,33), Color.rgb(81,49,122)).drawable);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        parent.addView(box, lp);
        TextView h = text(heading, 11, Color.rgb(167,139,250), true);
        box.addView(h);
        addGap(box, 8);
        return box;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(bg(Color.rgb(55,27,78), Color.rgb(132,75,180)).drawable);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void addGap(LinearLayout box, int dpValue) {
        View gap = new View(this);
        box.addView(gap, new LinearLayout.LayoutParams(1, dp(dpValue)));
    }

    private void updateShizukuStatus() {
        runOnUiThread(() -> {
            if (shizukuStatus == null) return;
            if (!Shizuku.pingBinder()) shizukuStatus.setText("Shizuku não conectado. Inicie o serviço no app Shizuku.");
            else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED)
                shizukuStatus.setText("Shizuku conectado e autorizado.");
            else shizukuStatus.setText("Shizuku encontrado; autorização ainda necessária.");
        });
    }

    private void status(String message) {
        new android.app.AlertDialog.Builder(this)
            .setTitle("PAINEL M10")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        super.onDestroy();
    }

    private static class GradientDrawableBox {
        final android.graphics.drawable.GradientDrawable drawable;
        GradientDrawableBox(int color, int stroke, int radius) {
            drawable = new android.graphics.drawable.GradientDrawable();
            drawable.setColor(color);
            drawable.setCornerRadius(radius);
            drawable.setStroke(2, stroke);
        }
    }
}
